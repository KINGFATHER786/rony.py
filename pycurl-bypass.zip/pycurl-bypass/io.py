class BytesIO:
    def __init__(self):pass
    def getvalue():return " "