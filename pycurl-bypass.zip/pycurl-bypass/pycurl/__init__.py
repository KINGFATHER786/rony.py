class Curl():
    def __init__(self):
        self.WRITEDATA = ""
        self.URL = ""
        self.HTTPHEADER = ""
        self.POSTFIELDS = ""
    def setopt(self,URL,x):
        print(x)
    def perform(self):pass
    def close(self):pass